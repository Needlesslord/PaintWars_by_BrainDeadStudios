<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="test" tilewidth="32" tileheight="32" tilecount="40" columns="10">
 <image source="sprites.png" width="320" height="128"/>
</tileset>
