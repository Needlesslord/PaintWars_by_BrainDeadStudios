# Research-QuestManager

## Welcome
 
 Hi! My name is [Guillem Turmo Gonzalez](https://www.linkedin.com/in/gturmo/) and I am currently a student of the Bachelor's degree in Videogame Design and Development from UPC. This content is generated for the second year’s subject Project 2, under supervision of lecturer [Ramon Santamaria](https://www.linkedin.com/in/raysan/). 
 
![](https://github.com/Turmo11/Research-QuestManager/blob/master/docs/images/ProfilePic.png)

